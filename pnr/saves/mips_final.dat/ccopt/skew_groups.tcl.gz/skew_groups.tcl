# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk/syn_constraints
create_ccopt_skew_group -name clk/syn_constraints -from_clocks {clk} -from_constraint_modes {syn_constraints} -from_delay_corners {CORNER_typ CORNER_typ} -target_insertion_delay 0.300 -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
